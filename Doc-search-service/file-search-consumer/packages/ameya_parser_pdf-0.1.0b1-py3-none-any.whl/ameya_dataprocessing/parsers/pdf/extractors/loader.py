import os
from easyocr import Reader

from ameya_dataprocessing.core.files.schema import Job
from ameya_dataprocessing.core.files.process_exception import PdfParserError

from .easyocr_extractor import easyocr_extractor
from .simple_reader_extractor import simple_directory_reader


class PDFExtractor:
    
    def __init__(self, easyocr_reader:Reader|None = None):
        
        if easyocr_reader and not isinstance(easyocr_reader, Reader):
            raise AttributeError("'easyocr_reader' must be an easyocr 'Reader' object.")
        
        easyocr_device = os.getenv("EASYOCR_DEVICE", "cpu")
        self.easyocr = easyocr_reader
        
        load_easyocr = True if os.getenv("LOAD_EASYOCR", "false").lower() == "true" else False
        if easyocr_reader is None and load_easyocr:
                self.easyocr = Reader(["en"], gpu= True if easyocr_device == "gpu" else False)
                

    
    async def extract(self, data:Job):
        
        u_file_paths = set()
        for i in data.file_path:
            _name, _ext = os.path.splitext(i)
            
            if _ext != ".pdf":
                raise PdfParserError("unsupported files are given. It will only support 'pdf' extension")
            
            u_file_paths.add(i)
        
        data.file_path = list(u_file_paths)
        
        if data.plan == "basic":
            docs = await simple_directory_reader(data)
        
        elif data.plan == "basic +":
            if self.easyocr and not isinstance(self.easyocr, Reader):
                raise AttributeError("EasyOCR does not initialized.")
            docs = await easyocr_extractor(self.easyocr, data)
        
        else:
            raise PdfParserError("unsupported extarction type is given. It will only support 'llama_parse', 'docling', 'simple_reader', 'paddle', 'easyocr'.")
        
        return docs