import os
import re
import gc
import fitz
import shutil
import random
import asyncio

from easyocr import Reader
from datetime import datetime

from llama_index.core.schema import Document

from ameya_dataprocessing.core.files.schema import Job
from ameya_dataprocessing.core.files.utils import add_metadata
from ameya_dataprocessing.parsers.pdf.logger.logger import logger
from ameya_dataprocessing.core.files.process_exception import EasyOCRExtractorError

lock = asyncio.Lock()



async def read_file(easyocr_reader:Reader, file_path:str, return_type:str="text", dpi:int=300):
    
    out_result = []
    _, _file = os.path.split(file_path)
    _name, _ = os.path.splitext(_file)
    _randvalue = random.randint(1, 99999999)
    dpi = int(os.getenv("IMAGE_DPI", 300)) or 300

    with fitz.open(file_path) as pdf:
        image_save_dir = os.path.join("temp/processed_files/temp_images",  _name + f"__{_randvalue}")
        
        for i, page in enumerate(pdf):
            page_text = ""
            if page.get_images(full=True) or page.find_tables().tables:
                
                image_save_path = os.path.join(image_save_dir, f"Page_{i}.png")
                os.makedirs(image_save_path, exist_ok=True)
                
                pix = page.get_pixmap(dpi=dpi)
                pix.save(image_save_path)
                
                results = easyocr_reader.readtext(image_save_path)
                
                for res in results:
                    page_text += res[1]
                    page_text += "\n"
                
                del results
                gc.collect()
                
                if not page_text:
                    pix = page.get_pixmap(dpi=dpi*2)
                    pix.save(image_save_path)
                    
                    results = easyocr_reader.readtext(image_save_path)
                
                    for res in results:
                        page_text += res[1]
                        page_text += "\n"
                        
                    del results
                    del pix
                
            else:
                page_text += page.get_text()
                
            if page_text:
                out_result.append(Document(text=page_text))
            else:
                logger.warning(f"The EasyOCR Extract does not found text in the page-{i+1} for {_file}")
                
    if os.path.exists(image_save_dir):
        shutil.rmtree(image_save_dir)
                
    return out_result


async def easyocr_extractor(easyocr_reader:Reader, job_data:Job) -> list[Document]:
        
    try:
        docs_out = []
        # usage = {}
        job_data.file_path = [job_data.file_path] if isinstance(job_data.file_path, str) else job_data.file_path
        
        for i in job_data.file_path:
            file_stat = os.stat(i)
            _dir, _file_name = os.path.split(i)
                
            logger.info(f"Started the EasyOCR Extract Event for job_id : {job_data.job_id}")
            logger.debug(f"Started the extraction of file named :- {_file_name}")
            
            async with lock:
                docs = await read_file(easyocr_reader, i)
            
            if docs:
                logger.debug(f"Extraction successfuly for file named :- {_file_name}")
                logger.info(f"Completed the EasyOCR Extract Event for job_id : {job_data.job_id}")
                
                job_data.extra_meta.update({"file_name": _file_name, "file_path": i, "file_type": "application/pdf",
                                            "file_size": file_stat.st_size, "creation_date": datetime.now(),
                                            "last_modified_date": datetime.now(),
                                            "correlation_id": job_data.correlation_id, "job_id": job_data.job_id,
                                            "checksum": job_data.checksums[_file_name]})
                
                docs = await add_metadata(docs, job_data.extra_meta)
                docs_out.extend(docs)
            
            else:
                logger.debug(f"Extraction failed for file named :- {_file_name}")
                docs_out.extend([])
        
        if docs_out:
            return docs_out
        
        else:
            logger.debug(f"Extraction failed for file named :- {_file_name}")
            logger.error("No documents extracted from the EasyOCR Extract process")
            raise EasyOCRExtractorError("No documents extracted from the EasyOCR Extract process")
        
    except Exception as e:
        logger.error(f"Error in the EasyOCR Extract process. Error: {e.__class__.__name__} :- {str(e)}")
        raise EasyOCRExtractorError(str(e))