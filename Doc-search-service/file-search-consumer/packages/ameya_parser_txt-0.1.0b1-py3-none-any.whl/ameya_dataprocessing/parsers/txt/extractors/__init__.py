from .loader import TxtExtractor

__all__ = ["TxtExtractor"]