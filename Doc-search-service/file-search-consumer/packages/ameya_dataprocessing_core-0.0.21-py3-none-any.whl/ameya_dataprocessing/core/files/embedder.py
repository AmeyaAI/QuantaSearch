import asyncio
from collections import defaultdict

from ameya.core.schema import EmbeddingData
from ameya.embedding import EmbeddingManager

from .schema import Job, ParserUsage
from .process_exception import EmbeddError

embed_man = EmbeddingManager()
semaphore = asyncio.Semaphore(10)

def _add_tokens(usage:ParserUsage, response:EmbeddingData):
    usage.input_tokens += response.usage.input_tokens
    usage.output_tokens += response.usage.output_tokens
    usage.total_tokens += response.usage.total_tokens

async def embed(job_data:Job) -> Job:

    try:
        embedd = await embed_man.initialize_embedding(provider=job_data.settings.embedding.provider,
                                                      api_key=job_data.settings.embedding.api_key,
                                                      model=job_data.settings.embedding.model)
        
        file_usage = defaultdict(ParserUsage)
        for i in job_data.extra_meta["docs"]:
            async with semaphore:
                embed_response = await embedd.aget_text_embedding(i.text)
                i.embedding = embed_response.embedding
                _add_tokens(file_usage[i.metadata["checksum"]], embed_response)
            
        job_data.extra_meta["usage"] = file_usage
        return job_data
    
    except Exception as e:
        raise EmbeddError(str(e))