from abc import ABC, abstractmethod
from typing import Any, Dict, List


class DataProcessingPipelineBase(ABC):  
    @abstractmethod
    def validate_file(self, file_path: str) -> bool:
        """Validate the input file."""
        raise NotImplementedError
    
    @abstractmethod
    def parse_file(self, file_path: str) -> Any:
        """Parse the input file."""
        raise NotImplementedError

    @abstractmethod
    def prepare_vector_metadata(self, parsed_data: Any) -> Dict[str, Any]:
        """Prepare file metadata for vector chunk"""
        raise NotImplementedError
    
    @abstractmethod
    def prepare_datasource(self, parsed_data: Any) -> Dict[str, Any]:
        """Prepare datasource information to store in Mongo DB"""
        raise NotImplementedError

    @abstractmethod
    def generate_property_graph(self, data: Any) -> Any:
        """Generate property graph from the data."""
        raise NotImplementedError

    @abstractmethod
    def ingest_vector_data(self, data: Any) -> bool:
        """Ingest vector data into the system."""
        raise NotImplementedError

    @abstractmethod
    def ingest_to_mongo(self, data: Any) -> bool:
        """Ingest data into MongoDB."""
        raise NotImplementedError

    @abstractmethod
    def notify(self, message: str) -> None:
        """Send notification about the process completion or errors."""
        raise NotImplementedError
    
    @abstractmethod
    def process(self, files: List[str]) -> None:
        """Main method to orchestrate the entire pipeline."""
        raise NotImplementedError