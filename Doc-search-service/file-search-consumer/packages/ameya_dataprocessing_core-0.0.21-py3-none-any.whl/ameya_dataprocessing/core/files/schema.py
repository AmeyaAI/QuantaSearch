from pydantic import BaseModel
from enum import Enum

thinking_models = ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite-preview-06-17"]

class LlamaPerPageCost(Enum):
    FAST = 1
    BALANCED = 3
    PREMIUM = 45
    COMPLEX_TABLES = 90
    
    
class DBSetting(BaseModel):
    db_provider: str
    db_url: str
    db_name: str
    collection_name: str | None


class LLMSettings(BaseModel):
    provider: str | None = None
    model: str | None = None
    api_key: str | None = None
    
    
class Setting(BaseModel):
    ocr: bool
    llm: LLMSettings
    embedding: LLMSettings
    llama_api_key: str | None = None
    extraction_type: str
    cache:bool = True
    
class Job(BaseModel):
    job_id: str
    file_path: str | list
    checksums: dict = {}
    settings: Setting
    db_config: DBSetting
    priority: int = 10
    result_type: str 
    service_name: str
    correlation_id: str | None = None
    reply_queue_name:str | None = None
    routing_key: str | None = None
    extra_meta: dict = {}
    plan: str = 'basic'
    call_back_url: str | None = None
    
    
class ParserUsage(BaseModel):
    input_tokens:int = 0
    output_tokens:int = 0
    total_tokens:int = 0
    llama_parse_total_credits_used: int = 0
    llama_parse_per_page_credits: int = 3
    
