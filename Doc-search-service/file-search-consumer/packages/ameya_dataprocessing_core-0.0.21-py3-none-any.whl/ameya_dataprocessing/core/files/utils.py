import os
import requests
from io import BufferedIOBase
from urllib.parse import urlparse
from requests.utils import unquote
from llama_index.core.schema import Document
from pathlib import Path, PurePath, PurePosixPath


def _is_url(file_path:str) -> bool:
        """Check if the input is a valid URL.

        This method checks for:
        - Proper URL scheme (http/https)
        - Valid URL structure
        - Network location (domain)
        """
        if not isinstance(file_path, str):
            return False
        try:
            result = urlparse(file_path)
            return all(
                [
                    result.scheme in ("http", "https"),
                    result.netloc,
                    result.scheme,
                ]
            )
        except Exception:
            return False

  

async def download_file(file_path:str, job_id:str):
    
    if isinstance(file_path, (str, PurePosixPath, Path, bytes, BufferedIOBase, PurePath)):
        
        _dir, _f_name = os.path.split(file_path)[0]
        folder_path = "temp/Upload_files"
        
        if isinstance(file_path, (bytes, BufferedIOBase)):
            cwd = os.getcwd()
            
            try:
                os.makedirs(os.path.join(cwd, folder_path, job_id), exist_ok=True, mode=0o777)
                
                with open(os.path.join(cwd, folder_path, job_id, _f_name), "wb+") as f:
                    f.write(file_path)
                
                return {"file_path": os.path.join(cwd, folder_path, job_id, _f_name), 
                        "dir_path": os.path.join(cwd, folder_path, job_id), "file_name": _f_name,
                        "status":"success", "error":None}
            
            except Exception as e:
                return {"file_path": os.path.join(cwd, folder_path, job_id, _f_name), 
                        "dir_path": os.path.join(cwd, folder_path, job_id), "file_name": _f_name,
                        "status":"failed", "error":str(e)}
            
        
        return {"file_path": file_path, 
                "dir_path": _dir, "file_name": _f_name,
                "status":"success", "error":None}
    
    elif _is_url(file_path):
        return await download_from_presigned(file_path, job_id)
    


async def download_from_presigned(presigned_url:str, job_id:str):
    
    cwd = os.getcwd()
    folder_path = "temp/Upload_files"
    os.makedirs(os.path.join(cwd, folder_path, job_id), exist_ok=True, mode=0o777)

    try:
        file_name = unquote(os.path.split(presigned_url.split("?")[0])[-1])

        data = requests.get(presigned_url, stream=True)

        with open(os.path.join(cwd, folder_path, job_id, file_name), "wb+") as f:
            for chunk in data.iter_content(131072):
                f.write(chunk)
        
        check = os.path.exists(os.path.join(cwd, folder_path, job_id, file_name))
        f_size = os.stat(os.path.join(cwd, folder_path, job_id, file_name)).st_size

        assert check and f_size > 0, "The downloaded file is corrupted while downloading."

        return {"file_path": os.path.join(cwd, folder_path, job_id, file_name), 
                "dir_path": os.path.join(cwd, folder_path, job_id), "file_name": file_name,
                "status":"success", "error":None}
    
    except Exception as e:
        return {"file_path": os.path.join(cwd, folder_path, job_id, file_name), 
                "dir_path": os.path.join(cwd, folder_path, job_id), "file_name": file_name,
                "status":"fail", "error":f"{e.__class__.__name__} : {str(e)}"}
        


async def add_metadata(doc:list[Document], extra_meta:dict) -> list[Document]:
    '''Add metadata to the given Document object.
    
    Args:
        - doc (Document) : The document object to add metadata.
        - extra_meta (Any) : The datas of the user.
    
    Returns:
        - Document
    '''
    for idx, i in enumerate(doc):
        extra_meta.update({"page_no": idx+1})
        keys = list(extra_meta.keys())
        
        i.excluded_llm_metadata_keys.extend(keys)
        i.excluded_embed_metadata_keys.extend(keys)
        i.metadata.update(extra_meta)
    
    return doc  