from abc import ABC,abstractmethod
from typing import List,Union,Any
from llama_index.core import Document


class DBPipelineBase(ABC):

    @abstractmethod
    def connection_verification(self,url:str) -> bool:
        raise NotImplementedError
    
    @abstractmethod
    def data_fetching(self,url) -> list:
        raise NotImplementedError
    
    @abstractmethod
    def ai_description_genearate(self,datas:Union[List[str],List[dict]],prompt:str) -> Union[str,dict]:
        raise NotImplementedError
    
    @abstractmethod
    def data_preparation(self,datas)-> dict:
        raise NotImplementedError
    
    @abstractmethod
    def document_chunck_preparation(self,data:dict)-> Document:
        raise NotImplementedError
    
    @abstractmethod
    def property_graph_generation(self,data:Any)-> Any:
        raise NotImplementedError
    
    @abstractmethod
    def vector_store(self,data:Document) -> str:
        raise NotImplementedError
    
    @abstractmethod
    def mongodb_store(self,data:dict)-> int:
        raise NotImplementedError
    
    @abstractmethod
    def notify(self,message:str)-> dict:
        raise NotImplementedError
    
    @abstractmethod
    def url_construct(connection_details:dict) -> str:
        raise NotImplementedError
    
    @abstractmethod
    def process(self) -> None:
        raise NotImplementedError