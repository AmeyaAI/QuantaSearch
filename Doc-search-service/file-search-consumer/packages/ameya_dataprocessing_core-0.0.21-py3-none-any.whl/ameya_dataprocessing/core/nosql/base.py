from abc import ABC, abstractmethod

class NoSqlDataProcessingPipleineBase(ABC):
    
    @abstractmethod
    async def connection_establishment(self):
        """Establish connection between for given host and create db and collection instance"""
        raise NotImplementedError
    
    @abstractmethod
    async def connection_validation(self):
        """Verification of the DB connection"""
        raise NotImplementedError
    
    @abstractmethod
    async def data_extraction(self):
        """Extraction of data to be processed"""
        raise NotImplementedError
    
    @abstractmethod
    async def data_processing(self):
        """Perform required data processing for the system"""
        raise NotImplementedError
    
    @abstractmethod
    async def notify(self):
        """To notify about events or errors"""
        raise NotImplementedError
    
    @abstractmethod
    async def process(self):
        """Orchastrator of the whole data preparation and processing flow"""
        raise NotImplementedError        