from pymongo import AsyncMongoClient


async def get_mongodb_collection(db_url:str, db_name:str, collection_name:str):
    
    client = AsyncMongoClient(db_url)
    
    if db_name not in await client.list_database_names():
        db = client[db_name]
        
    else:
        db = client[db_name]
        
    if collection_name not in await db.list_collection_names():
        await db.create_collection(collection_name)
    
    return db[collection_name]