import os

from ameya_dataprocessing.core.files.schema import Job
from ameya_dataprocessing.core.files.process_exception import CsvParserError

from .simple_reader_extractor import simple_directory_reader


class CsvExtractor:
    
    def __init__(self):
        pass
        
    async def extract(self, data:Job):
        
        u_file_paths = set()
        for i in data.file_path:
            _name, _ext = os.path.splitext(i)
            
            if _ext not in [".csv"]:
                raise CsvParserError("unsupported files are given. It will only support 'csv' extensions")
            
            u_file_paths.add(i)
        
        data.file_path = list(u_file_paths)
        
        if data.plan == "basic":
            docs = await simple_directory_reader(data)
        
        else:
            raise CsvParserError("unsupported Parsing type is given. It will only support 'simple_reader' parse type.")
        
        return docs