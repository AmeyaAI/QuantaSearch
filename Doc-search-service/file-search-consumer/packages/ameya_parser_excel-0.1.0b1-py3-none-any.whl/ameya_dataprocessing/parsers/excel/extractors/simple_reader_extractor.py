import os
import pandas as pd
from datetime import datetime

from llama_index.core.schema import Document
from llama_index.core import SimpleDirectoryReader

from ameya_dataprocessing.core.files.schema import Job
from ameya_dataprocessing.core.files.utils import add_metadata
from ameya_dataprocessing.parsers.excel.logger.logger import logger
from ameya_dataprocessing.core.files.process_exception import SimpleReaderExtractorError


class XLSXLoader:
    
    def __init__(self, result_type:str="text", chunk_size:int=102400):
        self.chunk_size = chunk_size
        self.result_type = result_type

    async def aload_data(self, file_path: str, **kwargs) -> list[Document]:
        count = 0
        df = pd.read_excel(file_path, engine="openpyxl")
       
        while True:
            if all(col.startswith("Unnamed") for col in df.columns):
                df = pd.read_excel(file_path, engine="openpyxl", skiprows=count+1)
                count += 1
            else:break
        
        num_rows = df.shape[0]
        file_stat = os.stat(file_path)
        _, _file_name = os.path.split(file_path)
        
        _row = 0
        chunk_num = 0
        documents = []
        
        while _row < num_rows:
            _p_row_num = 0
            
            for i in range(_row, num_rows):
                chunk = df.iloc[_row : i+1]
                
                if self.result_type == "text":
                    text = chunk.to_string(index=False)
                elif self.result_type == "markdown":
                    text = chunk.to_markdown(index=False)
                
                if len(text) < self.chunk_size:
                    _p_row_num = i
                else:break
            
            chunk = df.iloc[_row : _p_row_num]
            chunk_num += 1
            
            if self.result_type == "text":
                text = chunk.to_string(index=False)
            elif self.result_type == "markdown":
                text = chunk.to_markdown(index=False)
            
            doc = Document(text=text, metadata={"chunk_id": chunk_num})
            
            doc.metadata.update({"file_name": _file_name, "file_path": str(file_path), "file_type": "application/text",
                                 "file_size": file_stat.st_size, "creation_date": datetime.now(),
                                 "last_modified_date": datetime.now()})

            documents.append(doc)
            _row = _p_row_num + 1

        return documents
    

class XLSLoader:
    
    def __init__(self, result_type:str="text", chunk_size:int=102400):
        self.chunk_size = chunk_size
        self.result_type = result_type
        
    
    async def aload_data(self, file_path: str, **kwargs) -> list[Document]:
        count = 0
        df = pd.read_excel(file_path, engine="xlrd")
       
        while True:
            if all(col.startswith("Unnamed") for col in df.columns):
                df = pd.read_excel(file_path, engine="xlrd", skiprows=count+1)
                count += 1
            else:break
            
        num_rows = df.shape[0]
        file_stat = os.stat(file_path)
        _, _file_name = os.path.split(file_path)
        
        _row = 0
        chunk_num = 0
        documents = []
        
        while _row < num_rows:
            _p_row_num = 0
            
            for i in range(_row, num_rows):
                chunk = df.iloc[_row : i+1]
                
                if self.result_type == "text":
                    text = chunk.to_string(index=False)
                elif self.result_type == "markdown":
                    text = chunk.to_markdown(index=False)
                
                if len(text) < self.chunk_size:
                    _p_row_num = i
                else:break
            
            chunk = df.iloc[_row : _p_row_num]
            chunk_num += 1
            
            if self.result_type == "text":
                text = chunk.to_string(index=False)
            elif self.result_type == "markdown":
                text = chunk.to_markdown(index=False)
            
            doc = Document(text=text, metadata={"chunk_id": chunk_num})
            
            doc.metadata.update({"file_name": _file_name, "file_path": str(file_path), "file_type": "application/text",
                                 "file_size": file_stat.st_size, "creation_date": datetime.now(),
                                 "last_modified_date": datetime.now()})

            documents.append(doc)
            _row = _p_row_num + 1

        return documents




async def simple_directory_reader(job_data:Job) -> list[Document]:
        
    try:
        docs_out = []
        job_data.file_path = [job_data.file_path] if isinstance(job_data.file_path, str) else job_data.file_path
        
        for i in job_data.file_path:
            _, _file_name = os.path.split(i)
            
            logger.info(f"Started the Simple Reader Extract Event for job_id : {job_data.job_id}")
            logger.debug(f"Started the extraction of file named :- {_file_name}")
            
            docs = await SimpleDirectoryReader(input_files=[i], raise_on_error=True,
                                               file_extractor={".xlsx": XLSXLoader(result_type=job_data.result_type),
                                                               ".xls": XLSLoader(result_type=job_data.result_type)},
                                               
                                               ).aload_data()
                
            if not docs[0].text:
                logger.debug(f"Extraction failed for file named :- {_file_name}")
                docs_out.extend([])
                
            else:
                logger.debug(f"Extraction successfuly for file named :- {_file_name}")

                job_data.extra_meta.update({"correlation_id": job_data.correlation_id, "job_id": job_data.job_id,
                                            "checksum": job_data.checksums[_file_name]})
                
                docs = await add_metadata(docs, job_data.extra_meta)
                docs_out.extend(docs)
                
        if docs_out:
            logger.info(f"Completed the Simple Reader Extract Event for job_id : {job_data.job_id}")
            
            return docs_out
        
        else:
            logger.error("No documents extracted from the Simple Reader Extract process")
            raise SimpleReaderExtractorError("No documents extracted from the Simple Reader Extract process")
    
    except Exception as e:
        logger.error(f"Error in the Simple Reader Extract process. Error: {e.__class__.__name__} :- {str(e)}")
        raise SimpleReaderExtractorError(str(e))