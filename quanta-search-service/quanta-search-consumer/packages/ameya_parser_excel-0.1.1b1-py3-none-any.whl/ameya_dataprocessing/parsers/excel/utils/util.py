import sys
import base64
from google import genai
from google.genai import types
from llama_index.core.llms import CompletionResponse

from ameya_dataprocessing.core.files.schema import Job, thinking_models, ParserUsage

def genai_extract(job_data:Job, proc_fp:str, prompt:str):
    client = genai.Client(api_key=job_data.settings.llm.api_key)
                    
    with open(proc_fp, "rb") as f:
        data = base64.b64encode(f.read()).decode("utf-8")

    if sys.getsizeof(data) > 20*(1024**2): # 20MB
        myfile = client.files.upload(file=proc_fp)
        content = [myfile, prompt]
    
    else:
        content = [
                    types.Part.from_bytes(
                        data=data,
                        mime_type='text/csv',
                    ),
                    prompt]
        
    response = client.models.generate_content(
            model=job_data.settings.llm.model,
            contents=content,
            config=types.GenerateContentConfig(
                    thinking_config=types.ThinkingConfig(thinking_budget=-1 if job_data.settings.extraction_type == "llm-thought" else 0)
                    if job_data.settings.llm.model in thinking_models else None)
        )
    
    out = response.text.split("!------!")
    usage = ParserUsage()
    res_usage = response.usage_metadata
    usage.input_tokens = res_usage.prompt_token_count
    usage.total_tokens = res_usage.total_token_count
    usage.output_tokens = res_usage.candidates_token_count + (res_usage.thoughts_token_count if res_usage.thoughts_token_count else 0)
    
    return out, CompletionResponse(additional_kwargs={"usage":usage}, text="Success")