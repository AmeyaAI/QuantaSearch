import os

from llama_index.core.schema import Document
from llama_index.core import SimpleDirectoryReader

from ameya_dataprocessing.core.files.schema import Job
from ameya_dataprocessing.core.files.utils import add_metadata
from ameya_dataprocessing.parsers.doc.logger.logger import logger
from ameya_dataprocessing.core.files.process_exception import SimpleReaderExtractorError

    
async def simple_directory_reader(job_data:Job) -> list[Document]:
        
    try:
        docs_out = []
        job_data.file_path = [job_data.file_path] if isinstance(job_data.file_path, str) else job_data.file_path
        
        for i in job_data.file_path:
            _dir, _file_name = os.path.split(i)
            
            logger.info(f"Started the Simple Reader Extract Event for job_id : {job_data.job_id}")
            logger.debug(f"Started the extraction of file named :- {_file_name}")
            
            docs = await SimpleDirectoryReader(input_files=[i], raise_on_error=True).aload_data()
                
            if not docs[0].text:
                logger.debug(f"Extraction failed for file named :- {_file_name}")
                docs_out.extend([])
                
            else:
                logger.debug(f"Extraction successfuly for file named :- {_file_name}")

                job_data.extra_meta.update({"correlation_id": job_data.correlation_id, "job_id": job_data.job_id,
                                            "checksum": job_data.checksums[_file_name]})
                
                docs = await add_metadata(docs, job_data.extra_meta)
                docs_out.extend(docs)
                
        if docs_out:
            logger.info(f"Completed the Simple Reader Extract Event for job_id : {job_data.job_id}")
            
            return docs_out
        
        else:
            logger.error("No documents extracted from the Simple Reader Extract process")
            raise SimpleReaderExtractorError("No documents extracted from the Simple Reader Extract process")
    
    except Exception as e:
        logger.error(f"Error in the Simple Reader Extract process. Error: {e.__class__.__name__} :- {str(e)}")
        raise SimpleReaderExtractorError(str(e))