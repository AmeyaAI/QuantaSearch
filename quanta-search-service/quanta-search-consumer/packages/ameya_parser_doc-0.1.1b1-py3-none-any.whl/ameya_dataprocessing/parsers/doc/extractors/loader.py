import os
import shutil
from easyocr import Reader

from ameya_dataprocessing.core.files.schema import Job
from ameya_dataprocessing.core.files.process_exception import DocsParserError

from .easyocr_extractor import easyocr_extractor
from .simple_reader_extractor import simple_directory_reader


class DocsExtractor:
    
    def __init__(self, easyocr_reader:Reader|None = None):
        if not shutil.which("libreoffice"):
            raise DocsParserError("Libreoffice not found. Please install libreoffice using 'apt install libreoffice' or 'sudo apt install libreoffice'.")
        
        if easyocr_reader and not isinstance(easyocr_reader, Reader):
            raise AttributeError("'easyocr_reader' must be an easyocr 'Reader' object.")
        
        easyocr_device = os.getenv("EASYOCR_DEVICE", "cpu")
        self.easyocr = easyocr_reader
        
        load_easyocr = True if os.getenv("LOAD_EASYOCR", "false").lower() == "true" else False
        if easyocr_reader is None and load_easyocr:
                self.easyocr = Reader(["en"], gpu= True if easyocr_device == "gpu" else False)
        
        
    async def extract(self, data:Job):
        
        u_file_paths = set()
        for i in data.file_path:
            _name, _ext = os.path.splitext(i)
            
            if _ext not in [".doc", ".docx"]:
                raise DocsParserError("unsupported files are given. It will only support 'doc' and 'docx' extensions")
            
            u_file_paths.add(i)
        
        data.file_path = list(u_file_paths)
        
        if data.plan == "basic":
            docs = await simple_directory_reader(data)
        
        elif data.plan == "basic +":
            docs = await easyocr_extractor(self.easyocr, data)
        
        else:
            raise DocsParserError("unsupported extarction type is given. It will only support 'llama_parse', 'docling', 'simple_reader', 'paddle', 'easyocr'.")
        
        return docs