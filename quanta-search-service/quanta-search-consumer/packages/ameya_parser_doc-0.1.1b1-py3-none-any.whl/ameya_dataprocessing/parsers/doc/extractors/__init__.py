from .loader import DocsExtractor

__all__ = ["DocsExtractor"]